class Afazer {
    constructor(tarefa, data, horario, prioridade) {
        this.tarefa = tarefa;
        this.data = data;
        this.horario = horario;
        this.prioridade = prioridade;
    }
}

class AfazerCadastro {
    constructor() {
        this.afazeres = [];
        this.editandoIndex = null;
    }

    adicionarAfazer(afazer) {
        if (this.editandoIndex === null) {
            this.afazeres.push(afazer);
        } else {
            this.afazeres[this.editandoIndex] = afazer;
            this.editandoIndex = null;
            document.getElementById('submitButton').innerText = "Adicionar";
        }
        this.atualizarTabela();
        this.limparForm();
    }

    removerAfazer(indice) {
        this.afazeres.splice(indice, 1);
        this.atualizarTabela();
    }

    editarAfazer(indice) {
        const afazer = this.afazeres[indice];
        document.getElementById('tarefa').value = afazer.tarefa;
        document.getElementById('data').value = afazer.data;
        document.getElementById('horario').value = afazer.horario;
        document.getElementById('prioridade').value = afazer.prioridade;

        this.editandoIndex = indice;
        document.getElementById('submitButton').innerText = "Atualizar";
    }

    atualizarTabela() {
        const tabela = document.getElementById('tabelaAfazeres');
        tabela.innerHTML = "";

        for (let i = 0; i < this.afazeres.length; i++) {
            const afazer = this.afazeres[i];
            const linha = document.createElement('tr');
            linha.innerHTML = `
                <td>${afazer.tarefa}</td>
                <td>${afazer.data}</td>
                <td>${afazer.horario}</td>
                <td>${afazer.prioridade}</td>
                <td>
                    <button onclick="afazerCadastro.removerAfazer(${i})" class="btn btn-danger btn-sm">Remover</button>
                    <button onclick="afazerCadastro.editarAfazer(${i})" class="btn btn-secondary btn-sm">Editar</button>
                </td>
            `;
            tabela.appendChild(linha);
        }
    }

    limparForm() {
        document.getElementById('afazerForm').reset();
        this.editandoIndex = null;
        document.getElementById('submitButton').innerText = "Adicionar";
    }
}

const afazerCadastro = new AfazerCadastro();

const formulario = document.getElementById('afazerForm');
formulario.addEventListener('submit', function(evento) {
    evento.preventDefault();

    const tarefa = document.getElementById('tarefa').value;
    const data = document.getElementById('data').value;
    const horario = document.getElementById('horario').value;
    const prioridade = document.getElementById('prioridade').value;

    const afazer = new Afazer(tarefa, data, horario, prioridade);
    afazerCadastro.adicionarAfazer(afazer);
});
